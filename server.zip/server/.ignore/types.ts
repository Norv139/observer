export interface IBotDS{
    name: string,
    token: string
    code: null | number | string,
    status: "run" | "stoped",
    discription: string,
    process: any
}

