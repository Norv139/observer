import {describe, expect, test} from '@jest/globals';
import { ProcessManager } from "./processManager";

const pm = new ProcessManager(true)

const statusGL = [
    {"code": null, "discription": "", "name": "test_1", "process": null, "status": "run", "token": "hide"}, 
    {"code": null, "discription": "", "name": "test_2", "process": null, "status": "run", "token": "hide"}, 
    {"code": null, "discription": "", "name": "test_3", "process": null, "status": "run", "token": "hide"}
]

test('crtBot', () => {
    expect(pm.crtBot('123', 'test_1')).toBe(1);
    expect(pm.crtBot('234', 'test_2')).toBe(2);
    expect(pm.crtBot('345', 'test_3')).toBe(3);
    expect(pm.crtBot('345', 'test_4')).toBe('error: token is in use now');
});

test('status', () => {
    expect(pm.status()).toEqual(statusGL)
});

test('killProcess', () => {
    pm.killProcess(1)
    expect( pm.status() ).toEqual(statusGL.filter(item=> !['test_1', 'test_4'].includes(item.name) ))
    
    pm.killProcess(3)
    expect( pm.status() ).toEqual(statusGL.filter(item=> !['test_1', 'test_3', 'test_4'].includes(item.name) ))

    pm.killProcess(2)
    expect( pm.status() ).toEqual([])
});


test('difrend logic', () => {
    pm.crtBot('1', 'test_1')
    pm.crtBot('2', 'test_2')
    pm.crtBot('3', 'test_3')

    pm.killProcess(1)
    pm.killProcess(2)

    pm.crtBot('4', 'test_4')

    expect( pm.status().map(item => item.name) ).toEqual( ['test_3', 'test_4'])

    pm.killProcess(3)
    pm.killProcess(4)

    expect(pm.status()).toEqual([])

});