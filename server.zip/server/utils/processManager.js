const child_process = require("child_process");


class ProcessManager {
  constructor(test) {
    this.test = test;
    this.stackChildProcess = new Map();
  }

  crtBot(token, name, envObj = {}) {
    const hasToken = [...this.stackChildProcess.values()].find(
      (item) => item.token == token
    );

    const andOfMap = [...this.stackChildProcess.keys()].pop()

    var id = !andOfMap ? 1 : andOfMap + 1


    const file = this.test ? "bot/testFile.js" : "bot/observerDS.js";

    if (!!hasToken) {
      return 'error: token is in use now';
    }

    const anyProcess = child_process.fork(file, {
      silent: true,
      detached: true, 
      stdio: 'ignore',
    }, {
      env: {
        ...process.env,
        DISCORD_TOKEN: token,
        ...envObj,
      },
    });

    const obj = {
      name: name,
      token: token,
      code: null,
      status: "run",
      discription: "",
      process: anyProcess,
    };

    this.stackChildProcess.set(id, obj);

    anyProcess.on("close", (code, error, signal) => {
        const prcs = this.stackChildProcess.get(id);
  
        this.stackChildProcess.set(id, {
          ...obj,
          code: code,
          status: "stoped",
          discription: `${error}`,
          process: anyProcess,
        });
      });

    // -=-

    // (code, error, signal) => {
    //   const prcs = this.stackChildProcess.get(id);

    //   this.stackChildProcess.set(id, {
    //     ...obj,
    //     code: code,
    //     status: "stoped",
    //     discription: `${error}`,
    //     process: anyProcess,
    //   });
    // }

    return id;
  }

  killProcess(id) {
    const process = this.stackChildProcess.get(id);

    try {
      process?.process.kill();
    } catch (error) {
      console.log(error);
    }

    this.stackChildProcess.delete(id);
  }

  status(name = null, hideToken = true) {
    switch (name) {
      case null:
        try {
          return [...this.stackChildProcess.values()].map((item) => {
            return {
              ...item,
              token: hideToken ? "hide" : item.token,
              process: null,
            };
          });
        } catch (error) {
          console.log(error)
          return [];
        }
      default:
        return [...this.stackChildProcess.values()].map((item) => {
          return {
            ...item,
            token: hideToken ? "hide" : item.token,
            process: null,
          };
        });
        // return {
        //   ...this.stackChildProcess.find((item) => item.name === name),
        //   process: null,
        //   token: !!hideToken ? "hide" : token,
        // };
    }
  }
}

module.exports = { ProcessManager };
